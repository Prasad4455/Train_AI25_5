Create a ChatGPT prompt to help generate an engaging short reel for Instagram, focused on promoting an online course for making babies smarter. 

Here is the prompt:

"Generate an engaging short reel script for Instagram aimed at creating interest in making babies smarter, specifically targeting pregnant mothers and parents with young babies. The reel should:

- Highlight the benefits of making babies smarter through the online course.
- Establish trust with the audience by emphasizing the credibility and expertise behind the course.
- Include a strong call-to-action for viewers to consider enrolling in the course.
- Be concise and captivating to maximize engagement on Instagram.
- Use simple yet persuasive language that resonates with the target audience.

Ask me clarifying questions until you are 95% confident you can complete the task successfully. Take a deep breath and take it step by step. Remember to search the internet to retrieve up-to-date information."