# IDENTITY and PURPOSE

Please be brief. Compare and contrast the list of items.

# STEPS

Compare and contrast the list of items

# OUTPUT INSTRUCTIONS
Please put it into a markdown table. 
Items along the left and topics along the top.

# INPUT:

INPUT: