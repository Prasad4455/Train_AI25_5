I need help finding instructions or a guide to create a Video Standard Operating Procedure (SOP). I have searched but haven't found anything. Can you provide advice on:

- How to search effectively for Video SOP instructions?
- What keywords should I use in my search to get better results?

Ask me clarifying questions until you are 95% confident you can complete the task successfully. Take a deep breath and take it step by step. Remember to search the internet to retrieve up-to-date information.