
/// <reference types="@webgpu/types" />