import React from 'react';
import { HomePage } from '@/src/homepage/HomePage';

export default function Page() {
    return <>
        <HomePage />
        <div id="portal-container"></div>
    </>;
}
